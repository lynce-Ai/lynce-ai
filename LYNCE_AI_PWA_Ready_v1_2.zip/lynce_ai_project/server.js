import express from "express";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    if (!ai) return res.status(503).json({ error: "API key belum dipasang di server." });
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Pertanyaan masih kosong." });
    if (message.length > 4000) return res.status(413).json({ error: "Pertanyaan terlalu panjang (maksimal 4.000 karakter)." });

    const history = Array.isArray(req.body.history) ? req.body.history.slice(-8) : [];
    const transcript = history
      .filter(x => (x.role === "user" || x.role === "model") && typeof x.text === "string")
      .map(x => `${x.role === "user" ? "Pengguna" : "LYNCE AI"}: ${x.text.slice(0, 3000)}`)
      .join("\n\n");

    const prompt = `Kamu adalah LYNCE AI, asisten belajar berbahasa Indonesia yang ramah, jelas, dan teliti.
Bantu pengguna untuk semua pelajaran dan pengetahuan umum.
Aturan:
- Jawab pertanyaan secara langsung dengan bahasa Indonesia yang mudah dipahami.
- Untuk soal atau hitungan, jelaskan langkah-langkah penyelesaian secara berurutan, lalu berikan hasil akhir.
- Jika pertanyaan ambigu, jelaskan asumsi atau minta satu klarifikasi singkat.
- Jangan mengarang sumber, kutipan, angka, atau fakta. Jika tidak yakin, katakan dengan jujur.
- Untuk topik berisiko atau sensitif, berikan informasi yang aman dan sesuai usia.
- Gunakan format yang rapi dengan judul atau daftar bila membantu.
${transcript ? `\nRiwayat percakapan:\n${transcript}\n` : ""}
Pertanyaan terbaru: ${message}`;

    const result = await ai.interactions.create({
      model: process.env.GEMINI_MODEL || "gemini-3.8-flash",
      input: prompt
    });
    res.json({ answer: result.output_text || "Maaf, AI belum menghasilkan jawaban teks." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(500).json({ error: "Layanan AI sedang bermasalah. Coba lagi beberapa saat." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "LYNCE AI" }));
app.listen(PORT, () => console.log(`LYNCE AI berjalan di port ${PORT}`));
