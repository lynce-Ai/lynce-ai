# LYNCE AI — Project awal v1.0

Project ini berisi:
- `public/index.html`: tampilan splash/loading, beranda, kategori, dan chat.
- `server.js`: backend yang menghubungkan web ke Gemini API.
- `package.json`: daftar dependensi.
- `.env.example`: contoh variabel konfigurasi.

## Penting
Tampilan web bisa dibuka sebagai preview, tetapi jawaban AI sungguhan memerlukan backend yang berjalan dan API key. Jangan pernah menaruh API key di `index.html` atau membagikannya ke orang lain.

## Menjalankan di komputer / server Node.js
1. Pasang Node.js versi yang masih didukung.
2. Ekstrak folder project.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `GEMINI_API_KEY` di `.env` dengan API key milikmu. Simpan rahasia ini di server.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Jika hanya memakai HP Android
Kamu tetap bisa mengedit file HTML dari editor kode Android, tetapi agar AI online bekerja, backend Node.js harus di-deploy ke layanan hosting yang mendukung Node.js. Setelah backend online, domain web perlu diarahkan ke hosting tersebut atau frontend perlu dikonfigurasi untuk memakai alamat backend yang sama.

## Mengatur model
Model default pada server adalah `gemini-3.8-flash`. Kamu bisa mengubah `GEMINI_MODEL` di environment server jika model itu tidak tersedia pada akun/proyek API-mu.

## Batasan versi awal
- Belum ada login/akun pengguna.
- Riwayat chat hanya tersimpan sementara selama halaman masih terbuka.
- Belum ada unggah foto soal atau bank soal 20.000 item.
- Belum menjadi APK; ini adalah web app yang bisa dikembangkan menjadi PWA atau dibungkus menjadi APK setelah hosting siap.

Dokumentasi resmi Gemini API:
https://ai.google.dev/gemini-api/docs


## Menyiapkan versi aplikasi Android (PWA)
Project ini sudah memiliki manifest, service worker, dan ikon PWA.
1. Deploy seluruh project ke hosting HTTPS yang mendukung Node.js.
2. Pastikan halaman utama dan /manifest.webmanifest bisa dibuka.
3. Buka situs HTTPS LYNCE AI di Chrome Android, lalu pilih menu Chrome > Tambahkan ke layar utama.
4. Untuk membuat file APK/AAB, gunakan PWABuilder setelah situs online dan ikuti proses packaging serta signing.
5. ZIP ini belum berisi APK; proses build dan penandatanganan Android dilakukan terpisah.

Catatan: fitur AI tetap memerlukan internet, backend aktif, dan API yang dikonfigurasi aman.
